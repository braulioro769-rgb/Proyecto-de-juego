package entity;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class Enemy {

	public int life = 30;
	public int maxLife = 30;
	public boolean showLifeBar = false;
	int lifeBarCounter = 0;
    public int x, y;
    public int speed = 2;
    
    //movimiento
    public BufferedImage[] up = new BufferedImage[9];
    public BufferedImage[] down = new BufferedImage[9];
    public BufferedImage[] left = new BufferedImage[9];
    public BufferedImage[] right = new BufferedImage[9];

    public String direction = "down";

    int spriteCounter = 0;
    public int spriteNum = 0;
    
    //ataque
    public BufferedImage[] attackUp = new BufferedImage[8];
    public BufferedImage[] attackDown = new BufferedImage[8];
    public BufferedImage[] attackLeft = new BufferedImage[8];
    public BufferedImage[] attackRight = new BufferedImage[8];

    public boolean attacking = false;

    int attackCounter = 0;
    public int attackNum = 0;
    
    //"hitbox"
    public int solidAreaX = 8;
    public int solidAreaY = 8;
    public int solidAreaWidth = 32;
    public int solidAreaHeight = 32;

    public Enemy(int x, int y) {
        this.x = x;
        this.y = y;
        loadImages();
    }

    public void update(Player player) {

    	int dx = player.x - x;
    	int dy = player.y - y;

    	int playerLeft = player.x + player.solidAreaX;
    	int playerRight = playerLeft + player.solidAreaWidth;
    	int playerTop = player.y + player.solidAreaY;
    	int playerBottom = playerTop + player.solidAreaHeight;

    	int enemyLeft = x + solidAreaX;
    	int enemyRight = enemyLeft + solidAreaWidth;
    	int enemyTop = y + solidAreaY;
    	int enemyBottom = enemyTop + solidAreaHeight;

    	int range = 5;

    	if(playerRight > enemyLeft - range &&
    	   playerLeft < enemyRight + range &&
    	   playerBottom > enemyTop - range &&
    	   playerTop < enemyBottom + range) {

    	    attacking = true;

    	} else {
    	    attacking = false;
    	}

    	if(attacking) {

    	    attackCounter++;

    	    if(attackCounter > 0.3) {
    	        attackNum++;

    	        if(attackNum >= 8) {
    	            attackNum = 0;
    	            attackCounter = 0;
    	        }

    	        attackCounter = 0;
    	    }
    	}
    	
    	if(Math.abs(dx) > Math.abs(dy)) {
    	    //movimiento horizontal domina

    	    if(dx < 0) {
    	        x -= speed;
    	        direction = "left";
    	    } else {
    	        x += speed;
    	        direction = "right";
    	    }

    	} else {
    	    //movimiento vertical domina

    	    if(dy < 0) {
    	        y -= speed;
    	        direction = "up";
    	    } else {
    	        y += speed;
    	        direction = "down";
    	    }
    	}
        
        //barra de vida
        if(showLifeBar) {
            lifeBarCounter++;

            if(lifeBarCounter > 30) {
                showLifeBar = false;
                lifeBarCounter = 0;
            }
        }
        
        spriteCounter++;

        if(spriteCounter > 0.3) {
            spriteNum++;

            if(spriteNum >= 9) {
                spriteNum = 0;
            }

            spriteCounter = 0;
        }
    }
    
    public void loadImages() {
        try {
            for(int i = 0; i < 9; i++) {
                up[i] = ImageIO.read(getClass().getResourceAsStream("/enemies/zombie/move/zombie_u" + (i+1) + ".png"));
                down[i] = ImageIO.read(getClass().getResourceAsStream("/enemies/zombie/move/zombie_d" + (i+1) + ".png"));
                left[i] = ImageIO.read(getClass().getResourceAsStream("/enemies/zombie/move/zombie_l" + (i+1) + ".png"));
                right[i] = ImageIO.read(getClass().getResourceAsStream("/enemies/zombie/move/zombie_r" + (i+1) + ".png"));
            }
            
            for(int i = 0; i < 8; i++) {
                attackUp[i] = ImageIO.read(getClass().getResourceAsStream("/enemies/zombie/attack/zombie_au" + (i+1) + ".png"));
                attackDown[i] = ImageIO.read(getClass().getResourceAsStream("/enemies/zombie/attack/zombie_ad" + (i+1) + ".png"));
                attackLeft[i] = ImageIO.read(getClass().getResourceAsStream("/enemies/zombie/attack/zombie_al" + (i+1) + ".png"));
                attackRight[i] = ImageIO.read(getClass().getResourceAsStream("/enemies/zombie/attack/zombie_ar" + (i+1) + ".png"));
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
