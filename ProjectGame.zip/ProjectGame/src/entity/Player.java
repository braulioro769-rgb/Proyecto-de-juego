package entity;

import input.KeyHandler;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;

public class Player {

    public int x, y;
    public int speed = 4;
    public int life = 5;
    public boolean invincible = false;
    public int invincibleCounter = 0;

    KeyHandler keyH;
    
    //movimiento
    public BufferedImage[] up = new BufferedImage[9];
    public BufferedImage[] down = new BufferedImage[9];
    public BufferedImage[] left = new BufferedImage[9];
    public BufferedImage[] right = new BufferedImage[9];

    //idle
    public BufferedImage[] idleUp = new BufferedImage[2];
    public BufferedImage[] idleDown = new BufferedImage[2];
    public BufferedImage[] idleLeft = new BufferedImage[2];
    public BufferedImage[] idleRight = new BufferedImage[2];
    
    //ataque
    public BufferedImage[] attackUp = new BufferedImage[6];
    public BufferedImage[] attackDown = new BufferedImage[6];
    public BufferedImage[] attackLeft = new BufferedImage[6];
    public BufferedImage[] attackRight = new BufferedImage[6];
    
    public String direction = "down";

    int spriteCounter = 0;
    public int spriteNum = 0;
    int idleCounter = 0;
    public int idleNum = 0;
    public boolean moving = false;
    public boolean attacking = false;
    int attackCounter = 0;
    public int attackNum = 0;
    
    public String shootDirection = "down";
    
    //"hitbox"
    public int solidAreaX = 8;
    public int solidAreaY = 8;
    public int solidAreaWidth = 32;
    public int solidAreaHeight = 32;
    
    public Player(KeyHandler keyH) {
        this.keyH = keyH;

        x = 400;
        y = 300;
        
        loadImages();
    }
    
    public void update() {

    	moving = false;
    	spriteCounter++;
    	
    	if(attacking) {

    	    attackCounter++;

    	    if(attackCounter > 0.1) {
    	        attackNum++;

    	        if(attackNum >= 6) {
    	            attackNum = 0;
    	            attackCounter = 0;
    	            attacking = false;
    	        }

    	        attackCounter = 0;
    	    }

    	    return;
    	}
    	
        if(keyH.upPressed) {
            y -= speed;
            direction = "up";
            moving = true;
        }

        if(keyH.downPressed) {
            y += speed;
            direction = "down";
            moving = true;
        }

        if(keyH.leftPressed) {
            x -= speed;
            direction = "left";
            moving = true;
        }

        if(keyH.rightPressed) {
            x += speed;
            direction = "right";
            moving = true;
        }
        
     // animación solo si se mueve
        if(moving) {

            spriteCounter++;

            if(spriteCounter > 0.3) {
                spriteNum++;

                if(spriteNum >= 9) {
                    spriteNum = 0;
                }

                spriteCounter = 0;
            }

            idleNum = 0;

        } else {

            idleCounter++;

            if(idleCounter > 3) {
                idleNum++;

                if(idleNum >= 2) {
                    idleNum = 0;
                }

                idleCounter = 0;
            }

            spriteNum = 0;
        }
        
        if(keyH.upPressed) {
            shootDirection = "up";
        }
        if(keyH.downPressed) {
            shootDirection = "down";
        }
        if(keyH.leftPressed) {
            shootDirection = "left";
        }
        if(keyH.rightPressed) {
            shootDirection = "right";
        }
        
        //invencibilidad
        if(invincible) {
            invincibleCounter++;

            if(invincibleCounter > 15) { // 60 frames ≈ 1 segundo
                invincible = false;
                invincibleCounter = 0;
            }
        }
    }
    
    public void loadImages() {
    	
        try {
        	for(int i = 0; i < 2; i++) {
        	    idleUp[i] = ImageIO.read(getClass().getResourceAsStream("/players/noob/idle/noob_iu" + (i+1) + ".png"));
        	    idleDown[i] = ImageIO.read(getClass().getResourceAsStream("/players/noob/idle/noob_id" + (i+1) + ".png"));
        	    idleLeft[i] = ImageIO.read(getClass().getResourceAsStream("/players/noob/idle/noob_il" + (i+1) + ".png"));
        	    idleRight[i] = ImageIO.read(getClass().getResourceAsStream("/players/noob/idle/noob_ir" + (i+1) + ".png"));
        	}
        	
        	for(int i = 0; i < 9; i++) {
                up[i] = ImageIO.read(getClass().getResourceAsStream("/players/noob/move/noob_u" + (i+1) + ".png"));
                down[i] = ImageIO.read(getClass().getResourceAsStream("/players/noob/move/noob_d" + (i+1) + ".png"));
                left[i] = ImageIO.read(getClass().getResourceAsStream("/players/noob/move/noob_l" + (i+1) + ".png"));
                right[i] = ImageIO.read(getClass().getResourceAsStream("/players/noob/move/noob_r" + (i+1) + ".png"));
            }

        	for(int i = 0; i < 6; i++) {
        	    attackUp[i] = ImageIO.read(getClass().getResourceAsStream("/players/noob/attack/noob_au" + (i+1) + ".png"));
        	    attackDown[i] = ImageIO.read(getClass().getResourceAsStream("/players/noob/attack/noob_ad" + (i+1) + ".png"));
        	    attackLeft[i] = ImageIO.read(getClass().getResourceAsStream("/players/noob/attack/noob_al" + (i+1) + ".png"));
        	    attackRight[i] = ImageIO.read(getClass().getResourceAsStream("/players/noob/attack/noob_ar" + (i+1) + ".png"));
        	}
        	
        } catch(IOException e) {
            e.printStackTrace();
        }
    }
}
