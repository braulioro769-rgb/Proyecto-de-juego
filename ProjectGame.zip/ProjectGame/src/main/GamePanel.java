package main;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Font;
import input.KeyHandler;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import entity.Player;
import java.util.ArrayList;
import entity.Bullet;
import entity.Enemy;

public class GamePanel extends JPanel {
	
	int commandNum = 0;
	KeyHandler keyH = new KeyHandler();
	BufferedImage[] menuFrames;
	int frameIndex = 0;
	int frameCounter = 0;
	int cursorBlinkCounter = 0;
	boolean cursorVisible = true;
	boolean canPress = true;
	Player player = new Player(keyH);
	BufferedImage image = null;
	ArrayList<Bullet> bullets = new ArrayList<>();
	ArrayList<Enemy> enemies = new ArrayList<>();
	int shotCooldown = 0;
	boolean drawPlayer = true;
	int spawnCounter = 0;
	int spawnRate = 150;
	
	//Estructura de juego
	int gameState;
	final int MENU_STATE = 0;
	final int PLAY_STATE = 1;
	
	public GamePanel() {
		this.setPreferredSize(new Dimension(800, 600));
		this.setBackground(Color.black);
		this.addKeyListener(keyH);
		this.setFocusable(true);
		gameState = MENU_STATE;
		enemies.add(new Enemy(100, 100));
		enemies.add(new Enemy(700, 500));
		
		new Thread(() -> {
		    while(true) {
		        update();
		        repaint();

		        try {
		            Thread.sleep(100);
		        } catch (InterruptedException e) {
		            e.printStackTrace();
		        }
		    }
		}).start();
		
		menuFrames = new BufferedImage[20];

		try {
		    menuFrames[0] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg1.jpg"));
		    menuFrames[1] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg2.jpg"));
		    menuFrames[2] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg3.jpg"));
		    menuFrames[3] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg4.jpg"));
		    menuFrames[4] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg5.jpg"));
		    menuFrames[5] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg6.jpg"));
		    menuFrames[6] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg7.jpg"));
		    menuFrames[7] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg8.jpg"));
		    menuFrames[8] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg9.jpg"));
		    menuFrames[9] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg10.jpg"));
		    menuFrames[10] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg11.jpg"));
		    menuFrames[11] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg12.jpg"));
		    menuFrames[12] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg13.jpg"));
		    menuFrames[13] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg14.jpg"));
		    menuFrames[14] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg15.jpg"));
		    menuFrames[15] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg16.jpg"));
		    menuFrames[16] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg17.jpg"));
		    menuFrames[17] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg18.jpg"));
		    menuFrames[18] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg19.jpg"));
		    menuFrames[19] = ImageIO.read(getClass().getResourceAsStream("/menu/result_bg20.jpg"));
		} catch (IOException e) {
		    e.printStackTrace();
		}
	}
	
	@Override
	protected void paintComponent(Graphics g) {
	    super.paintComponent(g);

	    if(gameState == MENU_STATE) {
	        drawMenu(g);
	    }

	    if(gameState == PLAY_STATE) {
	        drawGame(g);
	    }
	}
	
	public void drawMenu(Graphics g) {
		g.drawImage(menuFrames[frameIndex], 0, 0, 800, 600, null);
		g.setColor(Color.white);
		//config titulo
		g.setFont(new Font("Arial", Font.BOLD, 50));
		// sombra
		g.setColor(Color.black);
		g.drawString("BULLET GAME", 203, 153);

		// texto real
		g.setColor(Color.white);
		g.drawString("BULLET GAME", 200, 150);
		//opciones
		g.setFont(new Font("Arial", Font.PLAIN, 30));
		//jugar
		g.drawString("Jugar", 350, 300);
		if(commandNum == 0 && cursorVisible) {
		    g.drawString(">", 320, 300);
		}
		//salir
		g.drawString("Salir", 350, 350);
		if(commandNum == 1 && cursorVisible) {
		    g.drawString(">", 320, 350);
		}
	}
	
	public void drawGame(Graphics g) {

	    //HUD
	    g.setColor(Color.white);
	    g.drawString("Vida: " + player.life, 20, 50);

	    BufferedImage image = null;

	    //Elegir imagen
	    if(player.attacking) {

	        switch(player.direction) {
	            case "up":
	                image = player.attackUp[player.attackNum];
	                break;
	            case "down":
	                image = player.attackDown[player.attackNum];
	                break;
	            case "left":
	                image = player.attackLeft[player.attackNum];
	                break;
	            case "right":
	                image = player.attackRight[player.attackNum];
	                break;
	        }

	    } else if(!player.moving) {

	        switch(player.direction) {
	            case "up":
	                image = player.idleUp[player.idleNum];
	                break;
	            case "down":
	                image = player.idleDown[player.idleNum];
	                break;
	            case "left":
	                image = player.idleLeft[player.idleNum];
	                break;
	            case "right":
	                image = player.idleRight[player.idleNum];
	                break;
	        }

	    } else {

	        switch(player.direction) {
	            case "up":
	                image = player.up[player.spriteNum];
	                break;
	            case "down":
	                image = player.down[player.spriteNum];
	                break;
	            case "left":
	                image = player.left[player.spriteNum];
	                break;
	            case "right":
	                image = player.right[player.spriteNum];
	                break;
	        }
	    }

	    //Parpadeo
	    boolean drawPlayer = true;

	    if(player.invincible) {
	        if(player.invincibleCounter % 10 < 5) {
	            drawPlayer = false;
	        }
	    }

	    //Dibujar
	    if(drawPlayer && image != null) {
	        g.drawImage(image, player.x, player.y, 48, 48, null);
	    }

	    //Balas
	    g.setColor(Color.yellow);
	    for(int i = 0; i < bullets.size(); i++) {
	        Bullet b = bullets.get(i);
	        g.fillRect(b.x, b.y, 10, 10);
	    }

	    //Enemigos
	    for(int i = 0; i < enemies.size(); i++) {
	        Enemy e = enemies.get(i);

	        BufferedImage enemyImage = null;

	        if(e.attacking) {

	            switch(e.direction) {
	                case "up":
	                    enemyImage = e.attackUp[e.attackNum];
	                    break;
	                case "down":
	                    enemyImage = e.attackDown[e.attackNum];
	                    break;
	                case "left":
	                    enemyImage = e.attackLeft[e.attackNum];
	                    break;
	                case "right":
	                    enemyImage = e.attackRight[e.attackNum];
	                    break;
	            }

	        } else {

	            switch(e.direction) {
	                case "up":
	                    enemyImage = e.up[e.spriteNum];
	                    break;
	                case "down":
	                    enemyImage = e.down[e.spriteNum];
	                    break;
	                case "left":
	                    enemyImage = e.left[e.spriteNum];
	                    break;
	                case "right":
	                    enemyImage = e.right[e.spriteNum];
	                    break;
	            }
	        }

	        if(enemyImage != null) {
	            g.drawImage(enemyImage, e.x, e.y, 40, 40, null);
	        }

	        //barra de vida
	        if(e.showLifeBar) {

	            int barWidth = 40;
	            int barHeight = 5;

	            int lifeWidth = (int)((double)e.life / e.maxLife * barWidth);

	            g.setColor(Color.red);
	            g.fillRect(e.x, e.y - 10, barWidth, barHeight);

	            g.setColor(Color.green);
	            g.fillRect(e.x, e.y - 10, lifeWidth, barHeight);
	        }
	    }
	}
	
	public void update() {

	    if(canPress) {

	        if(keyH.upPressed) {
	            commandNum--;
	            if(commandNum < 0) {
	                commandNum = 1;
	            }
	            canPress = false;
	        }

	        if(keyH.downPressed) {
	            commandNum++;
	            if(commandNum > 1) {
	                commandNum = 0;
	            }
	            canPress = false;
	        }

	        if(keyH.enterPressed) {

	        	if(commandNum == 0) {
	        	    gameState = PLAY_STATE;
	        	}

	            if(commandNum == 1) {
	                System.exit(0);
	            }

	            canPress = false;
	        }
	    }

	    if(!keyH.upPressed && !keyH.downPressed && !keyH.enterPressed) {
	        canPress = true;
	    }

	    //ANIMACIÓN DE FONDO
	    frameCounter++;

	    if(frameCounter > 1) {
	        frameIndex++;
	        if(frameIndex >= menuFrames.length) {
	            frameIndex = 0;
	        }
	        frameCounter = 0;
	    }

	    // PARPADEO DEL CURSOR
	    cursorBlinkCounter++;

	    if(cursorBlinkCounter > 10) {
	        cursorVisible = !cursorVisible;
	        cursorBlinkCounter = 0;
	    }
	    
	    if(gameState == PLAY_STATE) {
	        player.update();
	        
	        if(keyH.spacePressed && !player.attacking) {

	            player.attacking = true;

	            bullets.add(new Bullet(player.x + 20, player.y + 20, player.shootDirection));

	            keyH.spacePressed = false;
	        }

	        for(int i = 0; i < bullets.size(); i++) {
	            bullets.get(i).update();
	        }
	    }
	    
	    for(int i = 0; i < enemies.size(); i++) {
	        enemies.get(i).update(player);
	    } 
	    
	    //colision de disparo
	    for(int i = 0; i < bullets.size(); i++) {

	        Bullet b = bullets.get(i);

	        for(int j = 0; j < enemies.size(); j++) {

	            Enemy e = enemies.get(j);

	            if(b.x < e.x + 40 &&
	               b.x + 10 > e.x &&
	               b.y < e.y + 40 &&
	               b.y + 10 > e.y) {

	            	e.life -= 10; // daño

	            	e.showLifeBar = true;

	            	if(e.life <= 0) {
	            	    enemies.remove(j);
	            	}

	            	bullets.remove(i);
	            	break;
	            }
	        }
	    }
	    
	    if(shotCooldown > 0) {
	        shotCooldown--;
	    }

	    if(keyH.spacePressed && !player.attacking && shotCooldown == 0) {

	        player.attacking = true;

	        bullets.add(new Bullet(player.x + 20, player.y + 20, player.shootDirection));

	        shotCooldown = 3; //velocidad de disparo
	    }
	    
	    //colision del jugador
	    for(int i = 0; i < enemies.size(); i++) {

	        Enemy e = enemies.get(i);

	        int playerLeft = player.x + player.solidAreaX;
	        int playerRight = playerLeft + player.solidAreaWidth;
	        int playerTop = player.y + player.solidAreaY;
	        int playerBottom = playerTop + player.solidAreaHeight;

	        int enemyLeft = e.x + e.solidAreaX;
	        int enemyRight = enemyLeft + e.solidAreaWidth;
	        int enemyTop = e.y + e.solidAreaY;
	        int enemyBottom = enemyTop + e.solidAreaHeight;

	        if(playerRight > enemyLeft &&
	           playerLeft < enemyRight &&
	           playerBottom > enemyTop &&
	           playerTop < enemyBottom) {

	        	if(e.attacking && e.attackNum == 2) {

	                if(!player.invincible) {
	                    player.life--;
	                    player.invincible = true;
	                }
	            }

	            break;
	        }
	    }
	    
	    spawnCounter++;

	    if(spawnCounter >= spawnRate) {

	        int x, y;

	        do {
	            x = (int)(Math.random() * 800);
	            y = (int)(Math.random() * 600);
	        } while(Math.abs(x - player.x) < 100 && Math.abs(y - player.y) < 100);

	        enemies.add(new Enemy(x, y));

	        spawnCounter = 0;
	    }
	    
	    //GAME OVER
	    if(player.life <= 0) {
	        gameState = MENU_STATE;
	    }
	}

}
